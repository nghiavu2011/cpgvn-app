
import { GoogleGenAI, Modality } from "@google/genai";
import { SourceImage } from "../types";

const API_KEY = process.env.API_KEY || "";
const ai = new GoogleGenAI({ apiKey: API_KEY });

export type TourMoveType = 'pan-up' | 'pan-down' | 'pan-left' | 'pan-right' | 'orbit-left' | 'orbit-right' | 'zoom-in' | 'zoom-out';
export type TourEffectType = 'night' | 'day' | 'magic' | 'snow' | 'starry';
export type SketchStyle = 'pencil' | 'watercolor' | 'oil';

export const sourceImageToDataUrl = (image: SourceImage): string => {
    return `data:${image.mimeType};base64,${image.base64}`;
}

export const dataUrlToSourceImage = (dataUrl: string): SourceImage | null => {
    if (!dataUrl) return null;
    const [header, base64Data] = dataUrl.split(',');
    const mimeType = header.match(/:(.*?);/)?.[1];
    if (!base64Data || !mimeType) return null;
    return { base64: base64Data, mimeType };
};

const loadImage = (src: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(new Error(`Failed to load image`));
        img.src = src;
    });
};

// Centralized logic for calculating image placement within a new aspect ratio
const getPaddingInfo = (originalWidth: number, originalHeight: number, targetAspectRatio: number) => {
    let canvasWidth = originalWidth;
    let canvasHeight = originalHeight;
    let dx = 0;
    let dy = 0;

    const originalAspectRatio = originalWidth / originalHeight;

    // Small threshold for float comparison
    if (Math.abs(originalAspectRatio - targetAspectRatio) < 0.01) {
        return { canvasWidth, canvasHeight, dx, dy };
    }

    if (originalAspectRatio > targetAspectRatio) {
        // Image is wider than target (e.g. 16:9 into 4:3) -> Increase Height (vertical bars)
        canvasHeight = Math.round(originalWidth / targetAspectRatio);
        dy = Math.round((canvasHeight - originalHeight) / 2);
    } else {
        // Image is taller than target (e.g. 4:3 into 16:9) -> Increase Width (horizontal bars)
        canvasWidth = Math.round(originalHeight * targetAspectRatio);
        dx = Math.round((canvasWidth - originalWidth) / 2);
    }
    
    return { canvasWidth, canvasHeight, dx, dy };
};

const getCreativityInstruction = (level: number): string => {
    switch (level) {
        case 1:
            return "STRICTLY PRESERVE the geometry, structure, and perspective of the original image. Apply styles and materials very subtly. Change: 20%.";
        case 2:
            return "Preserve the main structure and geometry. Apply materials and lighting described in the prompt. Change: 40%.";
        case 3:
            return "Follow the composition of the original image, but feel free to modernize elements and update materials significantly. Change: 60%.";
        case 4:
            return "Use the original image as a structural reference, but redesign significant architectural elements and details to match the prompt. Change: 80%.";
        case 5:
            return "COMPLETELY REIMAGINE the scene. Use the original image only as a loose guide for camera angle. Be highly creative and prioritize the text prompt description over the source image. Change: 100%.";
        default:
            return "Follow the composition of the original image.";
    }
};

export const generateImages = async (
  sourceImage: SourceImage,
  prompt: string,
  type: 'exterior' | 'interior' | 'floorplan',
  numberOfImages: number,
  aspectRatio: string,
  referenceImage: SourceImage | null,
  isAnglePrompt: boolean = false,
  creativityLevel: number = 3
): Promise<string[]> => {
    const model = 'gemini-2.5-flash-image'; 
    
    const parts: any[] = [];
    parts.push({
        inlineData: {
            data: sourceImage.base64,
            mimeType: sourceImage.mimeType
        }
    });

    if (referenceImage) {
        parts.push({
            inlineData: {
                data: referenceImage.base64,
                mimeType: referenceImage.mimeType
            }
        });
        parts.push({ text: "Use the second image as a style reference." });
    }

    const creativityInstruction = getCreativityInstruction(creativityLevel);
    const finalPrompt = `
    TASK: Architectural Render.
    CREATIVITY_INSTRUCTION: ${creativityInstruction}
    USER_PROMPT: ${prompt}
    `;

    parts.push({ text: finalPrompt });

    let validRatio = "1:1";
    if (["1:1", "3:4", "4:3", "9:16", "16:9"].includes(aspectRatio)) {
        validRatio = aspectRatio;
    } else if (aspectRatio === 'Auto') {
        validRatio = "1:1"; 
    }

    try {
        const promises: Promise<any>[] = [];
        for(let i=0; i<numberOfImages; i++) {
            promises.push(ai.models.generateContent({
                model: model,
                contents: { parts },
                config: {
                    imageConfig: {
                        aspectRatio: validRatio
                    }
                }
            }));
        }
        
        const results = await Promise.all(promises);
        const images: string[] = [];

        results.forEach(res => {
            const part = res.candidates?.[0]?.content?.parts?.find((p: any) => p.inlineData);
            if(part?.inlineData?.data) {
                images.push(`data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`);
            }
        });
        
        return images;

    } catch (e) {
        console.error("Generate images failed", e);
        throw e;
    }
};

export const analyzeFloorplanPrompt = async (image: SourceImage, type: string, style: string): Promise<string | null> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: {
                parts: [
                    { inlineData: { data: image.base64, mimeType: image.mimeType } },
                    { text: `Analyze this ${type} drawing. Create a detailed architectural rendering prompt for a 3D visualization in the style of "${style}". Focus on layout, landscape elements, and spatial organization. Output only the prompt in English.` }
                ]
            }
        });
        return response.text || null;
    } catch (e) {
        console.error("Analysis failed", e);
        return null;
    }
};

export const analyzeLayout3DPrompt = async (
    sourceImage: SourceImage, 
    refImage: SourceImage | null,
    buildingStyle: string,
    angleStyle: string,
    interiorStyle: string,
    lighting: string
): Promise<string> => {
    const parts: any[] = [{ inlineData: { data: sourceImage.base64, mimeType: sourceImage.mimeType } }];
    if (refImage) parts.push({ inlineData: { data: refImage.base64, mimeType: refImage.mimeType } });

    const promptText = `Analyze this 2D plan and write a professional 3D architectural rendering prompt in English. 
    Building Category: ${buildingStyle}, Perspective/View: ${angleStyle}, Interior Decoration Style: ${interiorStyle}, Lighting Environment: ${lighting}. 
    Focus on materiality, realistic textures, and spatial clarity. Output the generated prompt ONLY.`;
    
    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts }
    });
    return response.text?.trim() || "";
};

export const upscaleImage = async (image: SourceImage, target: '2k' | '4k'): Promise<string | null> => {
    const model = 'gemini-2.5-flash-image';
    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: {
                parts: [
                    { inlineData: { data: image.base64, mimeType: image.mimeType } },
                    { text: "Upscale this image to high resolution, maintaining all details." }
                ]
            }
        });

        const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (part?.inlineData?.data) {
             return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
    } catch (e) {
        console.error("Upscale failed", e);
    }
    return null;
};

export const convertToSketchyStyle = async (image: SourceImage, type: 'interior' | 'exterior', style: SketchStyle = 'pencil'): Promise<string | null> => {
    let stylePrompt = "";
    switch(style) {
        case 'pencil':
            stylePrompt = "into a clean architectural pencil sketch, black and white hand-drawn look, graphite texture.";
            break;
        case 'watercolor':
            stylePrompt = "into a beautiful architectural watercolor painting, soft blended colors, artistic fluid strokes.";
            break;
        case 'oil':
            stylePrompt = "into a classic oil painting, rich textures, visible brushstrokes, vibrant artistic feel.";
            break;
    }

    const prompt = `Convert this ${type} image ${stylePrompt} Maintain architectural structure accurately.`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image', 
            contents: {
                parts: [
                    { inlineData: { data: image.base64, mimeType: image.mimeType } },
                    { text: prompt }
                ]
            }
        });
        const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (part?.inlineData?.data) {
                return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
    } catch (e) {
        console.error("Convert to sketch failed", e);
    }
    return null;
};

export const editImage = async (sourceImage: SourceImage, maskImage: SourceImage, prompt: string): Promise<string | null> => {
    try {
        const parts = [
            { inlineData: { data: sourceImage.base64, mimeType: sourceImage.mimeType } },
            { inlineData: { data: maskImage.base64, mimeType: maskImage.mimeType } },
            { text: `Edit the first image using the second image as a mask. WHITE pixels in mask are the area to edit. BLACK pixels are the area to PROTECT. Prompt: ${prompt}` }
        ];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts },
        });

        const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (part?.inlineData?.data) {
             const aiResultBase64 = part.inlineData.data;
             const aiResultMime = part.inlineData.mimeType || 'image/png';

             const originalImg = await loadImage(sourceImageToDataUrl(sourceImage));
             const maskImg = await loadImage(sourceImageToDataUrl(maskImage));
             const generatedImg = await loadImage(`data:${aiResultMime};base64,${aiResultBase64}`);

             const canvas = document.createElement('canvas');
             canvas.width = originalImg.naturalWidth;
             canvas.height = originalImg.naturalHeight;
             const ctx = canvas.getContext('2d');
             if (!ctx) throw new Error("Canvas context failed");

             ctx.drawImage(originalImg, 0, 0);

             const editCanvas = document.createElement('canvas');
             editCanvas.width = canvas.width;
             editCanvas.height = canvas.height;
             const editCtx = editCanvas.getContext('2d');
             if(!editCtx) throw new Error("Edit Canvas context failed");

             editCtx.drawImage(generatedImg, 0, 0, canvas.width, canvas.height);
             editCtx.globalCompositeOperation = 'destination-in';
             editCtx.drawImage(maskImg, 0, 0, canvas.width, canvas.height);

             ctx.drawImage(editCanvas, 0, 0);

             return canvas.toDataURL(sourceImage.mimeType);
        }
    } catch (e) {
        console.error("Edit failed", e);
        throw e;
    }
    return null;
};

export const generateEditPromptFromReference = async (
    sourceImage: SourceImage,
    maskImage: SourceImage,
    referenceImage: SourceImage
): Promise<string> => {
    if (!API_KEY) throw new Error("API_KEY is not configured.");

    const prompt = `
    You are an expert architectural designer. Analyze the Reference Image for style and apply it to the MASKED AREA of the Source Image. Output prompt ONLY.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                { inlineData: { data: sourceImage.base64, mimeType: sourceImage.mimeType } },
                { inlineData: { data: maskImage.base64, mimeType: maskImage.mimeType } },
                { inlineData: { data: referenceImage.base64, mimeType: referenceImage.mimeType } },
                { text: prompt }
            ]
        }
    });

    return response.text || "";
};

export const generateDiagramImage = async (
    sourceImage: SourceImage, 
    type: string, 
    notes: string, 
    numImages: number, 
    aspectRatio: string, 
    referenceImage: SourceImage | null
): Promise<string[]> => {
     const prompt = `Create an architectural diagram based on this image. Type: ${type}. Notes: ${notes}.`;
     return generateImages(sourceImage, prompt, 'exterior', numImages, aspectRatio, referenceImage);
};

export const generateVirtualTourImage = async (image: SourceImage, move: TourMoveType, magnitude: number): Promise<string | null> => {
    const prompt = `Generate a new view of this scene as if the camera moved: ${move} by ${magnitude} degrees. Maintain consistency.`;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image', 
            contents: {
                parts: [
                    { inlineData: { data: image.base64, mimeType: image.mimeType } },
                    { text: prompt }
                ]
            }
        });
        const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (part?.inlineData?.data) {
                return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
    } catch (e) {
        console.error("Virtual tour gen failed", e);
    }
    return null;
};

export const applyEffectToTourImage = async (image: SourceImage, effect: TourEffectType): Promise<string | null> => {
     const prompt = `Apply environmental effect: ${effect} to this scene. Keep the structure identical.`;
     try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image', 
            contents: {
                parts: [
                    { inlineData: { data: image.base64, mimeType: image.mimeType } },
                    { text: prompt }
                ]
            }
        });
        const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (part?.inlineData?.data) {
                return `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
        }
    } catch (e) {
        console.error("Apply effect failed", e);
    }
    return null;
}

export const generateDiagramPromptFromReference = async (
  sourceImage: SourceImage,
  referenceImage: SourceImage
): Promise<string> => {
  if (!API_KEY) throw new Error("API_KEY is not configured.");

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: {
      parts: [
        { inlineData: { data: sourceImage.base64, mimeType: sourceImage.mimeType } },
        { inlineData: { data: referenceImage.base64, mimeType: referenceImage.mimeType } },
        { text: "Analyze the Source for the subject. Analyze the Reference for the graphical style. Generate a Vietnamese prompt to transform Source into the style of Reference. Output only the prompt." },
      ],
    }
  });

  return response.text || "";
};

export const generateOutpaintingPrompt = async (sourceImage: SourceImage): Promise<string> => {
    if (!API_KEY) throw new Error("API_KEY is not configured.");

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: {
            parts: [
                { inlineData: { data: sourceImage.base64, mimeType: sourceImage.mimeType } },
                { text: "Analyze this image and describe what surroundings would naturally extend this scene. English, concise." }
            ]
        }
    });

    return response.text || "";
};

export const padImageToAspectRatioWithColor = async (image: SourceImage, targetAspectRatio: number, color: string = 'white'): Promise<SourceImage> => {
    const img = await loadImage(sourceImageToDataUrl(image));
    const { canvasWidth, canvasHeight, dx, dy } = getPaddingInfo(img.naturalWidth, img.naturalHeight, targetAspectRatio);

    const canvas = document.createElement('canvas');
    canvas.width = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get canvas context');
    
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, dx, dy);

    const dataUrl = canvas.toDataURL('image/png');
    return dataUrlToSourceImage(dataUrl)!;
};

export const outpaintImage = async (sourceImage: SourceImage, targetAspectRatio: number, prompt: string): Promise<string | null> => {
    const img = await loadImage(sourceImageToDataUrl(sourceImage));
    const { canvasWidth, canvasHeight, dx, dy } = getPaddingInfo(img.naturalWidth, img.naturalHeight, targetAspectRatio);

    const imageCanvas = document.createElement('canvas');
    imageCanvas.width = canvasWidth;
    imageCanvas.height = canvasHeight;
    const imgCtx = imageCanvas.getContext('2d');
    if (!imgCtx) throw new Error("Canvas context failed");
    
    imgCtx.fillStyle = 'black'; 
    imgCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    imgCtx.drawImage(img, dx, dy);
    const paddedBase64 = imageCanvas.toDataURL('image/png').split(',')[1];

    const maskCanvas = document.createElement('canvas');
    maskCanvas.width = canvasWidth;
    maskCanvas.height = canvasHeight;
    const maskCtx = maskCanvas.getContext('2d');
    if (!maskCtx) throw new Error("Canvas context failed");

    maskCtx.fillStyle = 'white'; 
    maskCtx.fillRect(0, 0, canvasWidth, canvasHeight);
    maskCtx.fillStyle = 'black'; 
    maskCtx.fillRect(dx, dy, img.naturalWidth, img.naturalHeight);
    const maskBase64 = maskCanvas.toDataURL('image/png').split(',')[1];
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [
                    { inlineData: { data: paddedBase64, mimeType: 'image/png' } },
                    { inlineData: { data: maskBase64, mimeType: 'image/png' } },
                    { text: `Outpaint this image. Extend content in white mask area using context: ${prompt}. Preserve original center perfectly.` }
                ]
            }
        });

        const part = response.candidates?.[0]?.content?.parts?.find(p => p.inlineData);
        if (part?.inlineData?.data) {
             const resultImg = await loadImage(`data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`);
             const finalCanvas = document.createElement('canvas');
             finalCanvas.width = canvasWidth;
             finalCanvas.height = canvasHeight;
             const fCtx = finalCanvas.getContext('2d');
             if(!fCtx) throw new Error("Canvas context failed");
             
             fCtx.drawImage(resultImg, 0, 0, canvasWidth, canvasHeight);
             fCtx.drawImage(img, dx, dy);
             return finalCanvas.toDataURL('image/png');
        }
    } catch (e) {
        console.error("Outpaint failed", e);
        throw e;
    }
    return null;
};
