export interface RenderHistoryItem {
  id: number;
  timestamp: string;
  images: string[];
  prompt: string;
}

export interface EditHistoryItem {
  id: number;
  timestamp: string;
  sourceImage: SourceImage;
  maskImage: SourceImage;
  prompt: string;
  resultImage: string;
}

export interface Layout3DHistoryItem {
  id: number;
  timestamp: string;
  sourceImage: SourceImage;
  images: string[];
  style: string;
  quality: string;
  tone: string;
}

export interface SourceImage {
  base64: string;
  mimeType: string;
}

export interface GeneratedPrompts {
  medium: string[];
  closeup: string[];
  interior: string[];
}

export interface RenderTabState {
  sourceImage: SourceImage | null;
  sketchyImage: SourceImage | null;
  referenceImage: SourceImage | null;
  generatedImages: string[];
  selectedImageIndex: number;
  useSketchyStyle: boolean;
  creativityLevel: number; // 1 to 5
}